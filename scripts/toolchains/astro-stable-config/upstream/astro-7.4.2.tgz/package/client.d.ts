/// <reference types="vite/types/import-meta.d.ts" />

/// <reference path="./types/actions.d.ts" />
/// <reference path="./types/content.d.ts" />
/// <reference path="./types/env.d.ts" />
/// <reference path="./types/fonts.d.ts" />
/// <reference path="./types/transitions.d.ts" />

interface ImportMetaEnv {
	// TODO: remove in Astro 8
	/**
	 * The prefix for Astro-generated asset links if the build.assetsPrefix config option is set. This can be used to create asset links not handled by Astro.
	 * @deprecated This will be removed in a future major version of Astro. Use `build.assetsPrefix` from `astro:config/server` instead.
	 */
	readonly ASSETS_PREFIX: string | Record<string, string>;
	/**
	 * This is set to the site option specified in your project’s Astro config file.
	 */
	readonly SITE: string;
}

interface ImportMeta {
	/**
	 * Astro and Vite expose environment variables through `import.meta.env`. For a complete list of the environment variables available, see the two references below.
	 *
	 * - [Astro reference](https://docs.astro.build/en/guides/environment-variables/#default-environment-variables)
	 * - [Vite reference](https://vite.dev/guide/env-and-mode.html#env-variables)
	 */
	readonly env: ImportMetaEnv;
}

declare module 'astro:assets' {
	// getImage's type here is different from the internal function since the Vite module implicitly pass the service config
	/**
	 * Get an optimized image and the necessary attributes to render it.
	 *
	 * **Example**
	 * ```astro
	 * ---
	 * import { getImage } from 'astro:assets';
	 * import originalImage from '../assets/image.png';
	 *
	 * const optimizedImage = await getImage({src: originalImage, width: 1280 });
	 * ---
	 * <img src={optimizedImage.src} {...optimizedImage.attributes} />
	 * ```
	 *
	 * This is functionally equivalent to using the `<Image />` component, as the component calls this function internally.
	 */
	export const getImage: (
		options: import('./dist/assets/types.js').UnresolvedImageTransform,
	) => Promise<import('./dist/assets/types.js').GetImageResult>;
	export const imageConfig: import('./dist/types/public/config.js').AstroConfig['image'];
	export const getConfiguredImageService: typeof import('./dist/assets/index.js').getConfiguredImageService;
	export const inferRemoteSize: typeof import('./dist/assets/utils/index.js').inferRemoteSize;
	export const Image: typeof import('./components/Image.astro').default;
	export const Picture: typeof import('./components/Picture.astro').default;
	export const Font: typeof import('./components/Font.astro').default;
	export const fontData: Record<
		import('astro:assets').CssVariable,
		Array<import('astro:assets').FontData>
	>;
	export const experimental_getFontFileURL: typeof import('./dist/assets/fonts/runtime.js').experimental_getFontFileURL;

	type ImgAttributes = import('./dist/type-utils.js').WithRequired<
		Omit<import('./types').HTMLAttributes<'img'>, 'src' | 'width' | 'height'>,
		'alt'
	>;

	export type LocalImageProps = import('./dist/type-utils.js').Simplify<
		import('./dist/assets/types.js').LocalImageProps<ImgAttributes>
	>;
	export type RemoteImageProps = import('./dist/type-utils.js').Simplify<
		import('./dist/assets/types.js').RemoteImageProps<ImgAttributes>
	>;
}

declare module 'virtual:astro:image-styles.css' {
	const styles: string;
	export default styles;
}

type ImageMetadata = import('./dist/assets/types.js').ImageMetadata;

declare module '*.gif' {
	const metadata: ImageMetadata;
	export default metadata;
}
declare module '*.jpeg' {
	const metadata: ImageMetadata;
	export default metadata;
}
declare module '*.jpg' {
	const metadata: ImageMetadata;
	export default metadata;
}
declare module '*.png' {
	const metadata: ImageMetadata;
	export default metadata;
}
declare module '*.apng' {
	const metadata: ImageMetadata;
	export default metadata;
}
declare module '*.tiff' {
	const metadata: ImageMetadata;
	export default metadata;
}
declare module '*.webp' {
	const metadata: ImageMetadata;
	export default metadata;
}
declare module '*.avif' {
	const metadata: ImageMetadata;
	export default metadata;
}
declare module '*.svg' {
	const Component: import('./types').SvgComponent & ImageMetadata;
	export default Component;
}

declare module 'astro:prefetch' {
	export { prefetch, PrefetchOptions } from 'astro/virtual-modules/prefetch.js';
}

declare module 'astro:i18n' {
	export * from 'astro/virtual-modules/i18n.js';
}

declare module 'astro:container' {
	export * from 'astro/virtual-modules/container.js';
}

declare module 'astro:middleware' {
	export * from 'astro/virtual-modules/middleware.js';
}

declare module 'astro:config/server' {
	// biome-ignore format: bug
	type ServerConfigSerialized = import('./dist/types/public/manifest.js').ServerDeserializedManifest;
	const manifest: ServerConfigSerialized;
	export = manifest;
}

declare module 'astro:config/client' {
	// biome-ignore format: bug
	type ClientConfigSerialized = import('./dist/types/public/manifest.js').ClientDeserializedManifest;
	const manifest: ClientConfigSerialized;
	export = manifest;
}

declare module 'astro:components' {
	export * from 'astro/components';
}

// TODO: remove in Astro 8
/**
 * @deprecated
 * `import { z } from 'astro:schema'` is deprecated and will be removed
 * in Astro 8. Use `import { z } from 'astro/zod'` instead.
 */
declare module 'astro:schema' {
	export * from 'astro/zod';
	import zod from 'astro/zod';

	/**
	 * @deprecated
	 * `import { z } from 'astro:schema'` is deprecated and will be removed
	 * in Astro 8. Use `import { z } from 'astro/zod'` instead.
	 */
	export const z = zod.z;
}

type MD = import('./dist/types/public/content.js').MarkdownInstance<Record<string, any>>;

interface ExportedMarkdownModuleEntities {
	frontmatter: MD['frontmatter'];
	file: MD['file'];
	url: MD['url'];
	getHeadings: MD['getHeadings'];
	Content: MD['Content'];
	rawContent: MD['rawContent'];
	compiledContent: MD['compiledContent'];
	load: MD['default'];
}

declare module '*.md' {
	const { load }: ExportedMarkdownModuleEntities;
	export const {
		frontmatter,
		file,
		url,
		getHeadings,
		Content,
		rawContent,
		compiledContent,
	}: ExportedMarkdownModuleEntities;
	export default load;
}

declare module '*.markdown' {
	const { load }: ExportedMarkdownModuleEntities;
	export const {
		frontmatter,
		file,
		url,
		getHeadings,
		Content,
		rawContent,
		compiledContent,
	}: ExportedMarkdownModuleEntities;
	export default load;
}

declare module '*.mkdn' {
	const { load }: ExportedMarkdownModuleEntities;
	export const {
		frontmatter,
		file,
		url,
		getHeadings,
		Content,
		rawContent,
		compiledContent,
	}: ExportedMarkdownModuleEntities;
	export default load;
}

declare module '*.mkd' {
	const { load }: ExportedMarkdownModuleEntities;
	export const {
		frontmatter,
		file,
		url,
		getHeadings,
		Content,
		rawContent,
		compiledContent,
	}: ExportedMarkdownModuleEntities;
	export default load;
}

declare module '*.mdwn' {
	const { load }: ExportedMarkdownModuleEntities;
	export const {
		frontmatter,
		file,
		url,
		getHeadings,
		Content,
		rawContent,
		compiledContent,
	}: ExportedMarkdownModuleEntities;
	export default load;
}

declare module '*.mdown' {
	const { load }: ExportedMarkdownModuleEntities;
	export const {
		frontmatter,
		file,
		url,
		getHeadings,
		Content,
		rawContent,
		compiledContent,
	}: ExportedMarkdownModuleEntities;
	export default load;
}

declare module '*.mdx' {
	type MDX = import('./dist/types/public/content.js').MDXInstance<Record<string, any>>;

	export const frontmatter: MDX['frontmatter'];
	export const file: MDX['file'];
	export const url: MDX['url'];
	export const getHeadings: MDX['getHeadings'];
	export const Content: MDX['Content'];
	export const components: MDX['components'];

	const load: MDX['default'];
	export default load;
}

declare module '*.html' {
	const Component: (opts?: { slots?: Record<string, string> }) => string;
	export default Component;
}

declare module 'astro:static-paths' {
	export const StaticPaths: typeof import('./dist/runtime/prerender/static-paths.js').StaticPaths;
}

// Everything below are Vite's types (apart from image types, which are in `client.d.ts`)

// CSS modules
type CSSModuleClasses = { readonly [key: string]: string };

declare module '*.module.css' {
	const classes: CSSModuleClasses;
	export default classes;
}
declare module '*.module.scss' {
	const classes: CSSModuleClasses;
	export default classes;
}
declare module '*.module.sass' {
	const classes: CSSModuleClasses;
	export default classes;
}
declare module '*.module.less' {
	const classes: CSSModuleClasses;
	export default classes;
}
declare module '*.module.styl' {
	const classes: CSSModuleClasses;
	export default classes;
}
declare module '*.module.stylus' {
	const classes: CSSModuleClasses;
	export default classes;
}
declare module '*.module.pcss' {
	const classes: CSSModuleClasses;
	export default classes;
}
declare module '*.module.sss' {
	const classes: CSSModuleClasses;
	export default classes;
}

// CSS
declare module '*.css' {
	const css: string;
	export default css;
}
declare module '*.scss' {
	const css: string;
	export default css;
}
declare module '*.sass' {
	const css: string;
	export default css;
}
declare module '*.less' {
	const css: string;
	export default css;
}
declare module '*.styl' {
	const css: string;
	export default css;
}
declare module '*.stylus' {
	const css: string;
	export default css;
}
declare module '*.pcss' {
	const css: string;
	export default css;
}
declare module '*.sss' {
	const css: string;
	export default css;
}

// Built-in asset types
// see `src/node/constants.ts`

// images
declare module '*.jfif' {
	const src: string;
	export default src;
}
declare module '*.pjpeg' {
	const src: string;
	export default src;
}
declare module '*.pjp' {
	const src: string;
	export default src;
}
declare module '*.ico' {
	const src: string;
	export default src;
}

// media
declare module '*.mp4' {
	const src: string;
	export default src;
}
declare module '*.webm' {
	const src: string;
	export default src;
}
declare module '*.ogg' {
	const src: string;
	export default src;
}
declare module '*.mp3' {
	const src: string;
	export default src;
}
declare module '*.wav' {
	const src: string;
	export default src;
}
declare module '*.flac' {
	const src: string;
	export default src;
}
declare module '*.aac' {
	const src: string;
	export default src;
}

declare module '*.opus' {
	const src: string;
	export default src;
}

// fonts
declare module '*.woff' {
	const src: string;
	export default src;
}
declare module '*.woff2' {
	const src: string;
	export default src;
}
declare module '*.eot' {
	const src: string;
	export default src;
}
declare module '*.ttf' {
	const src: string;
	export default src;
}
declare module '*.otf' {
	const src: string;
	export default src;
}

// other
declare module '*.webmanifest' {
	const src: string;
	export default src;
}
declare module '*.pdf' {
	const src: string;
	export default src;
}
declare module '*.txt' {
	const src: string;
	export default src;
}

// wasm?init
declare module '*.wasm?init' {
	const initWasm: (options: WebAssembly.Imports) => Promise<WebAssembly.Instance>;
	export default initWasm;
}

// web worker
declare module '*?worker' {
	const workerConstructor: {
		new (): Worker;
	};
	export default workerConstructor;
}

declare module '*?worker&inline' {
	const workerConstructor: {
		new (): Worker;
	};
	export default workerConstructor;
}

declare module '*?worker&url' {
	const src: string;
	export default src;
}

declare module '*?sharedworker' {
	const sharedWorkerConstructor: {
		new (): SharedWorker;
	};
	export default sharedWorkerConstructor;
}

declare module '*?sharedworker&inline' {
	const sharedWorkerConstructor: {
		new (): SharedWorker;
	};
	export default sharedWorkerConstructor;
}

declare module '*?sharedworker&url' {
	const src: string;
	export default src;
}

declare module '*?raw' {
	const src: string;
	export default src;
}

declare module '*?url' {
	const src: string;
	export default src;
}

declare module '*?inline' {
	const src: string;
	export default src;
}

declare module '*?no-inline' {
	const src: string;
	export default src;
}

declare module '*?url&inline' {
	const src: string;
	export default src;
}

declare module '*?url&no-inline' {
	const src: string;
	export default src;
}
